<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BETA PAPUA</title>

    <style>
        table {
            border-collapse: collapse;
            min-width: 500px;
        }

        th,
        td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }

        th {
            background-color: #f2f2f2;
        }

        #mapContainer {
            position: absolute;
        }

        #labelContainer {
            z-index: 999 !important;
            position: absolute;
        }

        #labelContainer div {
            position: absolute;
            font-size: .7em;
            background: rgba(255, 255, 255, 0.7);
            color: #000;
            padding: 2px;
            margin: 0;
            border-radius: 5px;
            box-shadow: 1px 1px 2px rgba(0, 0, 0, .5);
        }

        #flexContainer {
            flex-direction: row !important;
            /* background: red; */
        }

        @media only screen and (max-width: 800px) {
            #flexContainer {
                flex-direction: column !important;
                /* background: red; */
            }
        }
    </style>
</head>

<body>
    <h1>Map Beta Papua</h1>
    <div style="display: flex;" id="flexContainer">

        <div style="position: relative; flex: 1;">

            <table id="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Title</th>
                        <th>Total (Random)</th>
                    </tr>
                </thead>
                <tbody id="dataBody">
                    <!-- Dynamic data will be appended here -->
                </tbody>
            </table>
        </div>

        <!--  -->

        <div style="position: relative; flex: 1; ">
            <div>
                <h2 id="titleText">ARAHIN MOUSE KE AREA DULU</h2>
                <h1>(<span id="totalText">0</span>)</h1>
            </div>
            <div id="mapContainer">
                <object type="image/svg+xml" id="SVG" data="betapapua-plain.svg"></object>
            </div>
            <div id="labelContainer">

            </div>
        </div>


    </div>

    <script>
        var mySVG = document.getElementById("SVG");
        var svgDoc;
        var areaList = [];

        var data = [
            {
                id: "910201",
                title: "WAMENA",
                total: Math.floor(Math.random() * 100),
            },
            {
                id: "910203",
                title: "KURULU",
                total: Math.floor(Math.random() * 100),
            },
            {
                id: "910204",
                title: "ASOLOGAIMA",
                total: Math.floor(Math.random() * 100),
            },
            {
                id: "910212",
                title: "HUBIKOSI",
                total: Math.floor(Math.random() * 100),
            },
            {
                id: "910215",
                title: "BOLAKME",
                total: Math.floor(Math.random() * 100),
            },
            {
                id: "910225",
                title: "WALELAGAMA",
                total: Math.floor(Math.random() * 100),
            },
            {
                id: "910227",
                title: "MUSATFAK",
                total: Math.floor(Math.random() * 100),
            },
            { id: "910228", title: "WOLO", total: Math.floor(Math.random() * 100) },
            {
                id: "910229",
                title: "ASOLOKOBAL",
                total: Math.floor(Math.random() * 100),
            },
            {
                id: "910234",
                title: "PELEBAGA",
                total: Math.floor(Math.random() * 100),
            },
            {
                id: "910235",
                title: "YALENGGA",
                total: Math.floor(Math.random() * 100),
            },
        ];

        console.log("DUMMY DATA", data);

        function akuPapua(elemen, id) {
            console.log("over", id)
            elemen.style.fill = "red"


            data.forEach((d) => {
                if (d.id == id) {
                    document.getElementById('titleText').innerHTML = d.title
                    document.getElementById('totalText').innerHTML = d.total
                }
            })

        }


        function akuPapuaReset(elemen, id, defaultColor) {
            console.log("leave", id, defaultColor)

            dataset = getDataById(id)
            color = getColor(dataset)
            elemen.style.fill = color
        }

        function getDataById(id) {
            var dataset = null
            data.forEach((d) => {
                if (d.id == id) {
                    console.log("--", id, d.id)
                    dataset = d

                    // continue
                }
            })

            return dataset
        }

        function createTable() {
            const tableBody = document.getElementById("table");

            data.forEach(item => {
                const row = document.createElement("tr");
                const idCell = document.createElement("td");
                const titleCell = document.createElement("td");
                const totalCell = document.createElement("td");

                idCell.textContent = item.id;
                titleCell.textContent = item.title;
                totalCell.textContent = item.total;

                row.appendChild(idCell);
                row.appendChild(titleCell);
                row.appendChild(totalCell);

                tableBody.appendChild(row);
            });
        }

        function getColor(dataset) {
            var defaultColor
            if (dataset.total > 90) {
                defaultColor = "#145A32"
            } else if (dataset.total > 75) {
                defaultColor = "#28B463"
            } else if (dataset.total > 50) {
                defaultColor = "#58D68D"
            } else if (dataset.total > 25) {
                defaultColor = "#82E0AA"
            } else if (dataset.total > 10) {
                defaultColor = "#ABEBC6"
            } else {
                defaultColor = "#D5F5E3"
            }

            return defaultColor
        }

        function getOffset(el) {
            const rect = el.getBoundingClientRect();
            console.log("width", rect.width)
            return {
                left: rect.left + window.scrollX + (rect.width / 2 - 5),
                top: rect.top + window.scrollY + (rect.height / 2 - 5)
            };
        }


        mySVG.addEventListener(
            "load",
            function () {
                svgDoc = mySVG.contentDocument;

                createTable()

                //   console.log(svgDoc);

                const areas = svgDoc.getElementsByTagName("path");
                for (let i = 0; i < areas.length; i++) {
                    // console.log(i, " ==== ", areas[i].getAttribute("id"));

                    titleTag = areas[i].getElementsByTagName("title");
                    titleText = titleTag[0].innerHTML;
                    dataset = getDataById(areas[i].getAttribute("id"))
                    color = getColor(dataset)
                    areas[i].style.fill = color

                    console.log(i, " ==== ", color);

                    // console.log("xxx", dataset)


                    areaList[areas[i].getAttribute("id")] = {
                        id: areas[i].getAttribute("id"),
                        title: titleText,
                    };

                    areas[i].addEventListener('mouseover', () => {
                        // console.clear()
                        akuPapua(areas[i], areas[i].getAttribute("id"))
                    })

                    areas[i].addEventListener('mouseleave', () => {
                        // console.clear()
                        akuPapuaReset(areas[i], areas[i].getAttribute("id"), "blue")
                    })



                    // elemen.style.fill = "red"
                    offset = getOffset(areas[i])
                    console.log("posisi", offset)
                    let div = document.createElement("div");
                    div.style.left = offset.left + "px"
                    div.style.top = offset.top + "px"
                    div.innerText = dataset.total
                    document.getElementById("labelContainer").append(div)
                } // end loop

                console.log("SVG contentDocument Loaded!");
                console.log(areaList);
            },
            false
        );
    </script>
</body>

</html>